//libraries
const express = require("express");
const mongoose = require("mongoose");
const app = express();

//routes fetchers
const workoutRoutes = require('./routes/workouts.js')
app.use(express.json())

//middleware
app.use((req, res, next) => {
     console.log(req.path, req.method)
     next()
})

//routes
app.use("/api/workouts/", workoutRoutes)

//database connection
// mongo_url = 'mongodb+srv://sahibzadaabdullah8:zF9dHnZdCapXkWpF@mernstack.6dh6a1c.mongodb.net/?retryWrites=true&w=majority&appName=mernstack'
mongo_url = 'mongodb+srv://mern:mern123@cluster0.qmeob.mongodb.net/mern?retryWrites=true&w=majority&appName=Cluster0'
mongoose.connect(mongo_url)
  .then(() => {
    //Server listening
    const port = 3000;
    app.listen(port , () => {
        console.log("Connected to db and server running on http://localhost:" + port);
    });


  }).catch((error) => {
    console.log(error)
  })

